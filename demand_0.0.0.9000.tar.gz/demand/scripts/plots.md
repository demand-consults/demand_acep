For each meter (PQ, Wat1, Wat2, and Wat3), there are four plots showing the power (kW) trends per years, months, weekdays and days to help comparing the trends (Nov. 2017 to Apr. 2019)

* Power (kW) trend of a day for days (Day 1 to Day 31) per month 
* Power (kW) trend of a day for weekdays (Sunday to Saturday) per month
* Power (kW) trend of a day for months (Jan. to Dec.) per year
* Power (kW) trend of a month for months (Jan. to Dec.) per year




# PQ

## Power (kW) trend of a day for days (Day 1 to Day 31) per month 

![](plots_files/figure-html/unnamed-chunk-2-1.png)<!-- -->

## Power (kW) trend of a day for weekdays (Sunday to Saturday) per month

![](plots_files/figure-html/unnamed-chunk-3-1.png)<!-- -->

## Power (kW) trend of a day for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-4-1.png)<!-- -->

## Power (kW) trend of a month for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-5-1.png)<!-- -->

# Wat 1

## Power (kW) trend of a day for days (Day 1 to Day 31) per month 

![](plots_files/figure-html/unnamed-chunk-6-1.png)<!-- -->

## Power (kW) trend of a day for weekdays (Sunday to Saturday) per month

![](plots_files/figure-html/unnamed-chunk-7-1.png)<!-- -->

## Power (kW) trend of a day for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-8-1.png)<!-- -->

## Power (kW) trend of a month for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-9-1.png)<!-- -->


# Wat 2

## Power (kW) trend of a day for days (Day 1 to Day 31) per month 

![](plots_files/figure-html/unnamed-chunk-10-1.png)<!-- -->

## Power (kW) trend of a day for weekdays (Sunday to Saturday) per month

![](plots_files/figure-html/unnamed-chunk-11-1.png)<!-- -->

## Power (kW) trend of a day for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-12-1.png)<!-- -->

## Power (kW) trend of a month for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-13-1.png)<!-- -->

# Wat 3

## Power (kW) trend of a day for days (Day 1 to Day 31) per month 

![](plots_files/figure-html/unnamed-chunk-14-1.png)<!-- -->

## Power (kW) trend of a day for weekdays (Sunday to Saturday) per month

![](plots_files/figure-html/unnamed-chunk-15-1.png)<!-- -->

## Power (kW) trend of a day for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-16-1.png)<!-- -->

## Power (kW) trend of a month for months (Jan. to Dec.) per year

![](plots_files/figure-html/unnamed-chunk-17-1.png)<!-- -->
